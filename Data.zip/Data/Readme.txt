train/test_c{critiria_number}.csv
--Data for train/test. The first column is the health news and the second column is the label.